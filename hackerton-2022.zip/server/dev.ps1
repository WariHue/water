.\venv\Scripts

uvicorn main:app --reload --host 0.0.0.0